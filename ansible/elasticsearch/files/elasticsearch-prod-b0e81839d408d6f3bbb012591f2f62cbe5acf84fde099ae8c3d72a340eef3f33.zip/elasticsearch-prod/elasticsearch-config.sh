#!/usr/bin/env bash

LOG_DIR=/var/log/elasticsearch
DATA_DIR=/var/lib/elasticsearch

## Elasticsearch forms a cluster using this name.
CLUSTER_NAME="conductr-elasticsearch"
NUMBER_OF_SHARDS=5
BULK_API_QUEUE_SIZE="$NUMBER_OF_SHARDS"

## This is for clustering
ARR_ES_INTERNAL_OTHER_IPS=(${ES_INTERNAL_OTHER_IPS//:/ })
ARR_ES_INTERNAL_OTHER_PORTS=(${ES_INTERNAL_OTHER_PORTS//:/ })

if [ -z $ARR_ES_INTERNAL_OTHER_IPS ]; then
  UNICAST_OPTS=
else
  TEMP=""
  for i in ${!ARR_ES_INTERNAL_OTHER_IPS[*]}
  do
    TEMP="$TEMP,${ARR_ES_INTERNAL_OTHER_IPS[$i]}:${ARR_ES_INTERNAL_OTHER_PORTS[$i]}"
  done
  TEMP=${TEMP:1}
  UNICAST_OPTS="-Des.discovery.zen.ping.unicast.hosts=$TEMP"
fi

ES_JAVA_OPTS="-Des.path.logs=$LOG_DIR -Des.path.data=$DATA_DIR"
ES_JAVA_OPTS="$ES_JAVA_OPTS -Des.cluster.name=$CLUSTER_NAME"
ES_JAVA_OPTS="$ES_JAVA_OPTS -Des.discovery.zen.ping.multicast.enabled=false"
ES_JAVA_OPTS="$ES_JAVA_OPTS $UNICAST_OPTS"
ES_JAVA_OPTS="$ES_JAVA_OPTS -Des.index.number_of_shards=$NUMBER_OF_SHARDS"
ES_JAVA_OPTS="$ES_JAVA_OPTS -Des.threadpool.bulk.queue_size=$BULK_API_QUEUE_SIZE"
export ES_JAVA_OPTS="$ES_JAVA_OPTS"

NUMBER_OF_OTHER_NODES=`expr ${#ARR_ES_INTERNAL_OTHER_IPS[@]}`
if [ "$NUMBER_OF_OTHER_NODES" -gt "1" ]; then
  FIRST_NODE="${ARR_ES_INTERNAL_OTHER_IPS[0]}"

  # Set the minimum number of master nodes alive for a cluster to be functional.
  # When the number of master is below the minimum, the Elasticsearch cluster will cease function to prevent split-brain.
  # This number is (total number of nodes / 2) + 1
  NUMBER_OF_NODES=`expr $NUMBER_OF_OTHER_NODES + 1`
  HALF_NUMBER_OF_NODES=`expr $NUMBER_OF_NODES / 2`
  QUORUM_SIZE=`expr $HALF_NUMBER_OF_NODES + 1`
  ES_CLUSTER_SETTINGS_URL="http://$FIRST_NODE:9200/elastic-search/_cluster/settings"
  ES_CLUSTER_SETTINGS_JSON="{\"transient\" : {\"discovery.zen.minimum_master_nodes\" : $QUORUM_SIZE}}"
  curl -v -X PUT $ES_CLUSTER_SETTINGS_URL -d "$ES_CLUSTER_SETTINGS_JSON"

  # Sets the number of replicas within the cluster.
  # This is the number of copies of data to be spread across the cluster for redundancy purposes.
  # Assuming the current node hosts the primary copy of the data, we want other nodes to hold the replica copy of the
  # data.
  # Therefore the number is number of other nodes.
  ES_SETTINGS_URL="http://$FIRST_NODE:9200/elastic-search/_settings"
  ES_SETTINGS_JSON="{\"index\" : {\"number_of_replicas\" : $NUMBER_OF_OTHER_NODES}}"
  curl -v -X PUT $ES_SETTINGS_URL -d "$ES_SETTINGS_JSON"

fi
